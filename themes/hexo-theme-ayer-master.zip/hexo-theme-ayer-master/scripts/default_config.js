'use strict';

module.exports = {
  // 生成meta `generator`
  meta_generator: true
};
